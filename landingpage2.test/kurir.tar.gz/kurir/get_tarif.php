<?php
require 'config/db.php';

$stmt = $pdo->prepare("SELECT nilai FROM pengaturan WHERE nama = 'tarif_per_km'");
$stmt->execute();
$tarif = (int)$stmt->fetchColumn();

echo json_encode([
  "tarif" => $tarif
]);
