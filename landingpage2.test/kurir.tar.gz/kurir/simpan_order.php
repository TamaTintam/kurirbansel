<?php
require 'config/db.php';

$input = json_decode(file_get_contents("php://input"), true);

// Cek aksi yang diminta
$action = $input['action'] ?? 'simpan_order';

if ($action === 'simpan_tarif') {
    // Simpan tarif ke database
    $tarif = (int) $input['tarif'];

    $stmt = $pdo->prepare("UPDATE pengaturan SET nilai = ? WHERE nama = 'tarif_per_km'");
    $success = $stmt->execute([$tarif]);

    echo json_encode([
        "status" => $success ? "ok" : "fail"
    ]);
    exit;
}

// --- Proses simpan order seperti biasa ---
$kode_unik = 'KK' . rand(100000, 999999);

$stmt = $pdo->prepare("INSERT INTO pesanan (nama, wa, origin, destination, barang, ongkir, kode_unik) 
VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([
    $input['nama'],
    $input['wa'],
    $input['origin'],
    $input['destination'],
    $input['barang'],
    $input['ongkir'],
    $kode_unik
]);

echo json_encode([
    'status' => 'success',
    'kode' => $kode_unik
]);

